Gesti� dels processos de treball
Projecte Final de Carrera
Autor: Ivan Ortega Jim�nez
Consultor: Roman Roset Mayals
Titulaci�: Enginyeria Inform�tica
Curs: 2011 / 2012 (Segon semestre)

En aquest projecte es pret�n solucionar el problema d�acc�s als processos de treball de les normes ISO mitjan�ant una aplicaci� per a dispositius m�bils (tel�fons i tabletes) que suporten HTML5 i CSS3.
Aquesta aplicaci� de funcionament molt intu�tiu ser� accessible per qualsevol empleat d�una empresa determinada, i li permet consultar els processos de treball que li apliquen. Hi haur� diferents sistemes d�acc�s als processos de treball per tal de facilitar la utilitat de l�aplicaci� segons el perfil d�usuari.

